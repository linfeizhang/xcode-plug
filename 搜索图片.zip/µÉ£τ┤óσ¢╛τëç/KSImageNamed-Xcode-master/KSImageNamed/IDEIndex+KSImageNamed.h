//
//  IDEIndex+KSImageNamed.h
//  KSImageNamed
//
//  Created by Kent Sutherland on 1/23/13.
//
//

#import "XcodeMisc.h"

@interface IDEIndex (KSImageNamed)

@end
